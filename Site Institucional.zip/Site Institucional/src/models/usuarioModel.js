var database = require("../database/config")

function cadastrar(nome, email, senha, cargo) {
    var instrucaoSql = `
        INSERT INTO usuario (nome, email, senha, cargo) VALUES ('${nome}', '${email}', '${senha}', '${cargo}');
    `;
    return database.executar(instrucaoSql);
}

module.exports = {
    cadastrar
};